"""
Module that can be reused withing multiple app
"""

from zlm_core.zlm_settings import ZlmSettings
